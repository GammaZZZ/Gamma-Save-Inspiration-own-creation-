# Liquid Orb for React

把 `LiquidOrb.jsx` 和 `liquid-orb.js` 一起放到 React 项目里。组件使用 Canvas 2D，自带液体渲染和墨镜图层，依赖项只有项目里的 React。

```jsx
import { LiquidOrb, PALETTES } from './LiquidOrb.jsx';

export default function Example() {
  return (
    <LiquidOrb
      mode="bloom"
      colors={PALETTES.blue}
      speed={0.65}
      playing={true}
      size={320}
      label="戴着墨镜的蓝色流体球"
    />
  );
}
```

| Prop | 用法 | 默认值 |
| --- | --- | --- |
| `mode` | `'wave'`、`'jelly'` 或 `'bloom'` | `'jelly'` |
| `colors` | 三个六位 HEX 色值，按底色、过渡色、高光色排列 | `PALETTES.orange` |
| `speed` | 流动速度倍数，范围 `0` 到 `4`。设为 `0` 时静止 | `0.65` |
| `playing` | 传 `false` 暂停，传 `true` 续播 | 跟随系统的减少动态效果设置 |
| `size` | 像素数字或 CSS 宽度字符串，比如 `320` 或 `'80%'` | `360` |
| `label` | 屏幕阅读器使用的描述 | 英文球体描述 |
| `className`、`style` | 添加外部样式，例如 `style={{ margin: 'auto' }}` | 无 |

HTML 原型的 **Code** 页签会根据当前面板生成 JSX，用 **Copy JSX** 可以复制这组设置。改色和切换模式会保留当前动画时间。暂停和续播也沿用这个时间。
